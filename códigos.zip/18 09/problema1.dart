E? segundoElementoV2<E> (List<E> lista){
  return lista.last;
}

main(){
var lista =[5, 9, 8, 15, 78, 29, 22];
print(segundoElementoV2(lista)!);
}
