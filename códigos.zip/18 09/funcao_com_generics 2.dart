//criando uma função tipo Object
E? segundoElementoV2<E>(List<E> lista){
  return lista[1];
}

main() {
  var lista = [1, 'Ana', 3, 4, 5];
  print(segundoElementoV2(lista)!);
}