//criando função que recebe função como
//parametro
void executarPor(int qtde, Function fn){
  for(var i = 0; i < qtde; i++) {
    fn();
  }
}

class i {
}

void main() {
  var minhaFunc = () => print("Muito Legal");
  executarPor(10, minhaFunc);
}