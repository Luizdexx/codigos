E?nome<E> (List<E> lista){
  for (var i = 0; i <= lista.length; i++) {
    if (lista[i].runtimeType == String){
      return lista[i];
    }
  }
}

main(){
var lista =[5, 9, 8, "Pedro", 78, 29, "Ana"];
print(nome(lista)!);
}