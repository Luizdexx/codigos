//criando uma função tipo Object
Object segundoElementoV1(List lista){
  return lista[1];
}

main() {
  var lista = [1, 2, 3, 4, 5];
  print(segundoElementoV1(lista));
}