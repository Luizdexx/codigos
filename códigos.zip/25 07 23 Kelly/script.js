const produto = {
    Item: 'Celular',
    Marca: 'Samsung',
    Preço: 1.783,
    Descrição: 'Eletrônico',
    Categoria: 'Android, 6 Gb RAM, 125 Gb',
};