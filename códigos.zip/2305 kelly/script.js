function TratrarErro(){
    try{valorInexistente
    }catch(e){
        console.log("Ocorreu um erro:" + e.message)
    }
}
  function Continuar(){
     const txtnumero = document.querySelector('.inNumero').value
     const res = document.querySelector('.resultado')
      if (numero==10){
        res.innerHTML =  `<p>0 $(numero) é 10</p>`
     }else if (numnero>10){  
       res.innerHTML = `<p>0 ${numero}é maior que 10</p>`
    }else{
    res.innerHTML = `<p>0 ${numero}é menor que 10</P>`
    }
  }

   