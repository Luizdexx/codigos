//função Mep (Mapear/Modificar)

main(){
  //criando uma lista com números
  var numeros = [1.0,2.0,3.0,4.0,5.0];
  print(numeros);

  //crinado variável do tipo função
  //que recebe parâmetro e retorna o dobro
  var dobro = (numero) => numero*2;

  //lista resultado recebe lista numeros
  //modificando cada valor para o dobro
  var resultado = numeros.map(dobro);
  print(resultado);
}