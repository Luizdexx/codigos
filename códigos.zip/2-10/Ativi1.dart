void main(){
  var nomes = ["Ane", "Beto", "Laura", "Beatriz", "Marcele"];
  
  var contar = (nome) => nome.length;
  var multiDez = (numero) => numero*10;

   var resultado = nomes.map(contar).map(multiDez);
  print(resultado);

}