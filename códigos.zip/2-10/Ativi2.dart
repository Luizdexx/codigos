void main(){
 
 var nomes = ['Ana', 'Bia', 'Carlos', 'Daniel', 'Maria', 'Pedro'];
  var total = nomes.reduce(virgula);
  print(total);
}

String virgula (String acumulador, String nome){
  return acumulador + ", " + nome;
}