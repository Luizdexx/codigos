function soma (n1,n2){
    return n1+n2
}

console.log((soma(10,10)))

function ImprimeMensagem(mensagem){
    return mensagem
}
console.log(ImprimeMensagem("Olá  2° info"));

function calcularMedia(nota1, nota2,nota3){
    return console.log((nota1+nota2+nota3)/3)
}
calcularMedia(10,8,6)