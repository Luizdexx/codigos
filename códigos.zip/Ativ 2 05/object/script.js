let pessoas = { 
    nome: "Pedro",
   idade: 34,
   genero: 'Masculino',

}
 console.log(pessoas.nome, pessoas.idade, pessoas.genero);

 let livro = {
    título: "Origem",
    autor: "Dan Brown",
    ano: 2016,
 }
 console.log(livro.título, livro.autor, livro.ano);

 let aluno = {
    nome: "Lucas",
    nota1: 8,
    nota2: 7,

    
}
aluno.media=(aluno.nota1+aluno.nota2)/2   
console.log(aluno.media);



