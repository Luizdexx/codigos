import 'dart:io';
void man(){
 // Área do triangulo = base * altura * altura  
 
   
   print("Informe o valor da base do triangulo ");
   // ignore: unused_local_variable
   var base = stdin.readLineSync()!;

   
   
}