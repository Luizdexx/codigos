void main(){
  print("Olá Dart");
  print('Tudo bem?');
  print('Claro, td bem!');

  {
    ;
    ;
    ;
  }
  
  if (true){
    print('Teste verdadeiro');
  }
  // ignore: dead_code
  if (false){
    print('Teste falso');
  }
}