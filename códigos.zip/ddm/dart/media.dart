import 'dart:io';

void main(){
 print('Digite o seu primeiro nome');
 var nome1 = stdin.readLineSync()!;
 print('Digite a primeira idade');
 var idade1 = double.parse(stdin.readLineSync()!);

 print('Digite o seu segundo nome');
 var nome2 = stdin.readLineSync()!;
 print('Digite a primeira idade');
 var idade2 = double.parse(stdin.readLineSync()!);
 
 print("A média das idades de ${nome1} e ${nome2}: ${(idade1 + idade2) /2} ");

}