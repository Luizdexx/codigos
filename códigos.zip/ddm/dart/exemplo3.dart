void man(){
  var n1 = 2;
  var n2 = 4.56;
  var t1 = "texto";
  t1 = "3";

  print(n1+n2);

  print(n1.runtimeType);
  print(n2.runtimeType);
  print(t1.runtimeType);


}