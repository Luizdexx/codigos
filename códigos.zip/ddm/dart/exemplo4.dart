void main(){
  var t1 = "salgado na cantina ";
  var t2 = "custa exatamente: ";
  var valor = 8.0;

  print(t1 + t2);
  print(t1 + t2 + valor.toString());
}