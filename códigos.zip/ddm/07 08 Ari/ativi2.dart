import 'dart:math';

void main(){
  var n1 = Random().nextInt(101);
  var n2 = Random().nextInt(101);
  var n3 = Random().nextInt(101);
  print("numeros: $n1, n2, n3.");

  int menor = n1;
  if(n2 < menor ) menor = n2;
  if (n3 < menor) menor = n1;
}