void main(){
  String idade = "32";
  double salario = 4560.9;
  String nome = "Maria Silva";
  String sexo = "F";
  
  String frase1 =
  idade + "Você tem" + nome + " Esse é seu";

}