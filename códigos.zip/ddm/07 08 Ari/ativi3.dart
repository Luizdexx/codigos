main() {
  var nota = 2.3;

  if(nota >= 9) {
    print('Parabéns! Você foi brilhante');
  }

}
