import 'dart:math';

void main(){
  var nota = Random().nextInt(11);
  print("Nota selecionada foi $nota.");

  if(nota < 9)
  {
  print("MB");

 }else if (nota>=7){
  print("B");
 }else if (nota >=5){
  print("R");
 }else {
  print("I");
 }
}