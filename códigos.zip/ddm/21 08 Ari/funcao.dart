void main(){
  //Exemplo Função sem retorno

  int a = 2;
  int b = 3;
  print(a + b);

  int c = 4;
  int d = 5;
  somaComPrint(c, d);
  
}
//Criando função sem retorno
void somaComPrint(int a, int b) {
  print(a + b);
}