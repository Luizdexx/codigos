import 'dart:math';

void main() {
  int resultado = somar(2, 3);
  print(resultado);

  print("O resultado é: ${somarNumnerosAleatorios()}");
}
int somar (int a, int b){
return a + b;
}

int somarNumnerosAleatorios(){
  int a = Random().nextInt(11);
  int b = Random().nextInt(11);
  return a + b;
}