

void main() {
  for (var i = 0; i < 4; i++) {
    
    var n1 = Random().nextInt(11);
    var n2 = Random().nextInt(11);
    var n3 = Random().nextInt(11);
    var n4 = Random().nextInt(11);
    

  }
}










