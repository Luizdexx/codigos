void main () {
  List<String> materia = ['portugues', 'matematica', 'historia', 'geografia'];
  materia.add ('biologia');
  materia.add ('quimica');
  print(materia);
}