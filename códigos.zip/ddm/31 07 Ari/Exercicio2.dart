void main () {
  Map<String, Double> doces [
   'paçoca'
   'cocada'
   'quindin'
   'marmelada'
   'bolo de chocolate'
  ];
}