void main() {
  //criando lista genérica
  List<String> frutas = ['banana', 'maça', 'laranja'];
  frutas.add('morango');
  print(frutas);

  //criando um Map genérico
  Map<String, double> salarios = {
    'gerente': 185748.4,'vendedor': 546.9};
    print(salarios);
    
}