//List
//Conjunto de elementos indexado a partir de 0
//Pode ter repetição e aceita valores de tipos diferentes 

void main() {
  //criando listas
  var aprovados = [ ' Ana', 'Carlos', 'Daniel'];
  //adicionado nome a lista
  aprovados.add('Daniel');
  //Mostrando a lista
  print(aprovados);
  //Mostrar elementos específico
  print(aprovados.elementAt(2));

  //Map
  //Chave : valor
  //Não aceita repetição, se duplicar, considera o último
  //declarando o Map
  var telefones = {
    'João': '(15) 9645-8654',
    'Maria': '(15) 9047-3764'
  };
  //mostrando Maps
  print(telefones);
  //mostrando campo específico
  print(telefones['João']);
}