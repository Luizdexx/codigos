//Criando função somaFn
//tipo / nome da variável / (parâmetros)
int SomaFn(int a, int b) {
  return a + b;
}

void main(){
  //mostrando função comum
  //tipo / nome / (parâmetros) = valor; 
  print("Função comum: ${SomaFn(10, 20)}");

  //criando uma variável do tipo função e
  //atribuindo a função somaFn
  int Function(int,int) soma1 = SomaFn;
  //mostrando variável do tipo função
  //que recebe a função somaFn
  print("Variável do tipo função: ${soma1(10,20)}");

  //criando um variável por inferência (põe o mouse) e
  //atribuindo uma função anônima que serve para isso
  var soma2 = (int x, int y) {
    return x + y;
  };
  //mostrando variável do tipo função
  //que recebeu função anônima
  print("variável do tipo função 2: ${soma2(10, 20)}");
}