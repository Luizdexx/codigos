void main(){
  var mult = (int a, int b)  => a * b;
}