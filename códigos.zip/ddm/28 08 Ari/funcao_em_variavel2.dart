void main() {
  //va que recebe dunção anônima
  var subt = (int x, int y){
    return x - y;
  };
//mostrando variável
print(subt(10, 5));

//versão simplificada
//criando uma variável por inferência
//atribuindo função anônima com arrow
//variável = função anônima => retorno
var sub2 = (int a, int b) => a - b;
//mostrando
print("arrow: ${sub2(10, 5)}");
}
