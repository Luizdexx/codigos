void main() {
  var profissoes = { 'Engenheiro', 'Médico', 
  'Dentista', 'Carteiro', 'Metaleiro', 'Vidraceiro'};
   print(profissoes);
   print(profissoes);
   print(profissoes.length);
     

}