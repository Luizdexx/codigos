void main(){
  var pessoas = {'Gabriel','João', 'Pedro', 'Lucas', 'Vitor', 'Luiz'};
  
}