void main() {
  var filmes = {
    'Star Wars Ep IV ',
  'Luke skywallker', 
  'Darth Vader', 
  'Han Solo', 
  'Princesa Leia', 
  'Yoda'};
  filmes.add('R2-D2');
  filmes.add('C3PO');
  filmes.add('Jabba');
  print(filmes.length);
  print(filmes.contains('Star Wars Ep IV'));
  print(filmes.first);
  print(filmes.last);
  print(filmes);
}