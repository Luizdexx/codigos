//Set
//Conjunto de elementos que não aceita
//repetição
//Não indexado
//As estroturas podem ser homgêneas
//ou heterogêneas
void main(){
  var times = {'Vasco', 'Santos', 'Palmeiras'};
  print(times is Set);
  times.add('Palmeiras');
  times.add('Palmeiras');
  times.add('Palmeiras');
  print(times.length);
  print(times.contains('Vasco'));
  print(times.first);
  print(times.last);
  print(times);
}