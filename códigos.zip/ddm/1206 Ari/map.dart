void main() {
  var telefones = {
    'João': '+55 (11) 997857778',
    'Maria': '+55 (15) 99275644',
    'Pedro': '+55 (18) 99656578',
    'João': '+55 (16) 998233217',
  };
  print(telefones is Map);
  print(telefones);
  print(telefones ['João']);
  print(telefones.length);
  print(telefones.keys);
  print(telefones.values);
}