void main(){
//criando um List
var notas = [8.9, 9.3, 7.8, 6.9, 9.1];

//mostrando List com for simples
for(int i = 0; i < notas.length; i++) {
  print("notas $i = ${notas[i]}");
}
//mostrando List com for in
for(var nota in notas) {
  print("O valor de nota é:$nota");
}
}