import 'dart:math';

void main() {
  
  Random random = new Random();
  int dentro = 0;
  int fora = 0;

  for (int i = 0; i < 20; i++) {
    int numAleatorio = random.nextInt(101);
    print(numAleatorio);

    if (numAleatorio >=10 && numAleatorio <= 20) {
      dentro++;
    }else {
      fora++;
    }
  }
  print("Numeros dentro do intervalo: $dentro");
  print("Numero fora do intervalo: $fora");
}