void main() {
  //for simples
  for(int a=1;a<=10; a++){
    print("a = $a");
  }

  //for decrementando do 4 em 4
  for(int b=100; b>=0; b -= 4){
    print("b = $b");
  }
}