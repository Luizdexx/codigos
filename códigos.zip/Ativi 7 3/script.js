console.log('Atividade 1')

let valorProduto = prompt('Informe o valor do produto:') 
valorDesconto = valorProduto*0.10
valorFinal = alert('O valor do produto com desconto é ${valorProduto - valorDesconto}')


console.log(' Atividade 2')

console. log(' O resultado da expressão (5+8)*12/4-6 é ${(5+8)*12/4-6}')

console.log(' Atividade 3')
let metro = 1
 console.log('1 metro convertido em centimetro é ${metro*100}')

 console.log('Atividade 4')
 let celsius = prompt('Graus celsius')

 let num1 = 0.1+0.2
 num1 = parseFloat(num1.toFixed(2)) 
 console.log(num1);
 