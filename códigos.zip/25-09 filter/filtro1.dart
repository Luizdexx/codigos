void main(){
//criando uma lista e atribuindo valores
var notas = [8.2,7.1,6.2,4.4,3.9,8.8];
//criando uma lista vazia
var notasBoas = [];

//percorrendo a lista
for (var nota in notas){
  if(nota>=7){
    notasBoas.add(nota);
  }
}
print(notas);
print(notasBoas);

}