void main(){
  var notas = [8.2,4.5,6.7,8.8,10.0 ];

  //criando variavel do tipo função
  //atribuindo uma função anônima que retorna
  //verdadeiro ou falso
  var notasBoasFn = (double nota) => nota >=7;
  var notasMuitoBoasFn = (double nota) => nota >=8.8;

  //lista notasBoas recebe listas notas
  //com o método where filtrado os valores
  //maiores ou iguais a 7
  var notasBoas = notas.where(notasBoasFn);
  var notasMuitoBoas = notas.where(notasMuitoBoasFn);
  print(notas);
  print(notasBoas);
  print(notasMuitoBoas);

   
  
  }