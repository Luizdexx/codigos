void main(){
  var notas = [5.4,7.8,8.9,6.7,9.0,1.5];
  
  var notaMBFn = (double nota) => nota <= 9.0;
   var notaMB = notas.where(notaMBFn);
  
  var notaBFn = (double nota) => 7 && nota <=7;
  var notaB = notas.where(notaBFn);
  
  var notaRFn = (double nota) => 7 && nota <=6;
  var notaR = notas.where(notaRFn);
  
  var notaIFn = (double nota) => nota <= 6;
  var notaI = notas.where(notaIFn);
 
  }