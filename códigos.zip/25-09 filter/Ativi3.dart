void main(){
var elementos = [5,7, "Maria",8.5,"João",6,"Luara",9,10,8,7,1];
var nomes = (var elemento) => elemento is String;
var numeros = ( var elemento) => elemento is num;
 
 var nome = elementos.where(nomes);
 var numero = elementos.where(numeros);

 print(elementos);
 print("Nomes: ${nome}");
 print("Numeros: ${numero}");
}


