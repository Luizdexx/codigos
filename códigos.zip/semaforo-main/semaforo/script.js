const img = document.querySelector("img");
const botoes = document.querySelectorAll("button");
let intervailID = null;
let automaticoAtivo = false;
let cont = 0;
for(const botao of botoes) {
  botao.addEventListener ("click", () =>{
   if (botao.classList.contains("automatico")) {
    if (automaticoAtivo) {
        clearInterval(intervailID);
        autommaticoAtivo = false
    }else {
        automaticoAtivo = true;
        intervailID = setInterval(() =>{
         if (cont === 0) {
            img.setAttribute("src", "./img/vermelho.png");
         }else if (cont === 1) {
            img.setAttribute("src", "./img/amarelo.png");
         } else if (cont === 2) {
            img.setAttribute("src", "./verde.png");
         }
         cont++;
         if (cont === 3) {
            cont = 0;
         }
    },1000);
  }
}
else {
    clearInterval(intervailID);
    automaticoAtivo = false;
    img.setAttribute("src", `./img/${botao.id}.png`);
}
   
   img.setAttribute("src", `./img/${botao.id}.png`);
  });
}