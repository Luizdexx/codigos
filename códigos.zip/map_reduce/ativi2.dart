void main(){
  var alunos = [
    {'nome': 'Alfredo', 'nota': 9.9},
    {'nome': 'Wilson', 'nota': 9.3},
    {'nome': 'Joana', 'nota': 8.7},
    {'nome': 'Guilherme', 'nota': 8.1},
    {'nome': 'Ana', 'nota': 7.6},
    {'nome': 'Bia', 'nota': 6.8},
  ];

   var nomes = alunos.map((nome) => nome['nomes']);
   print("Nomes: $nomes");
   
   var nota = alunos.map((aluno) => aluno['nota']);
   print("Somente notas: $nota");

  var notasBoas = alunos.where((nota) => nota! >= 9.3);
  print("Notas Boas: $notasBoas");


}