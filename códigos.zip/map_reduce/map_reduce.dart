void main(){
  //Map, filter e reduce
  //Lista de Maps(Chave:valor)
  var alunos = [
    {'nota': 9.9},
    {'nota': 9.3},
    {'nota': 8.7},
    {'nota': 8.1},
    {'nota': 7.6},
    {'nota': 6.8},

  ];
  print(alunos);

  //Transformando(Map) em lista de notas
  var notas = alunos.map((aluno) => aluno['nota']);
  print("Somente notas: $notas");

  var notasBoas = notas.where((nota) => nota! >= 9.0);
  print("Notas Boas: $notasBoas");

  var tudoJunto = notas.map((e) => e as double)
  .reduce((value, element) => value + element);
  print("soma: $tudoJunto");
}