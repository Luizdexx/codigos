void main(){
  var alunos = [
    {'nome': 'Bruna'},
    {'nome': 'Wilson'},
    {'nome': 'Marilha'},
    {'nome': 'Guilherme'},
    {'nome': 'Bruna'},
    {'nome': 'Robson'},
  ];
  var nomes = alunos.map((aluno) => aluno['nome']);

  var bruna = nomes.where((nome) => nome == "Bruna");
  
  var juntos = nomes.map((e) => e as String).reduce((value, element) => value + '-' + element);

  print(nomes);
  print(bruna);
  print(juntos);
}