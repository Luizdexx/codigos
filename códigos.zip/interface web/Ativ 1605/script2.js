const pessoa = {nome:"Paula", idade: '28', profissão: "Advogada"}
const capturaPessoa = document.querySelector("#pessoa")
capturaPessoa.innerHTML += `<p> Exibe nome: ${pessoa.nome}<p>`
capturaPessoa.innerHTML += `<p> Exibe idade: ${pessoa.idade}<p>`
capturaPessoa.innerHTML += `<p> Exibe profissão: ${pessoa.profissão}<p>`

const usuario ={
    nome: "Gabriel", 
    idade: '22', 
    email: "gabri3l@gmail.com"
   }
   
   const capturaUsuario = document.querySelector(".usuario")
capturaUsuario.innerHTML += `<p> Exibe nome: ${usuario.nome}<p>`
capturaUsuario.innerHTML += `<p> Exibe idade: ${usuario.idade}<p>`
capturaUsuario.innerHTML += `<p> Exibe email: ${usuario.email}<p>`

function calcula(n1, n2){
    return n1*n2;
}

const capturaResultado = document.querySelector('.resultado')
capturaResultado.innerHTML += `<p> O resultado da multiplicação é:${calcula(2,3)}<p>` 

function areaRetangulo(base, altura){
    return base*altura;
}

const CapturaArea = document.querySelector('.area')
CapturaArea.innerHTML += `<p> Area do retangulo: ${areaRetangulo(10, 4)}<p>`


