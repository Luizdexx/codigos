const datanasc = prompt('informe a data de nascimento:')
document.body.innerHTML= 'Sua data de nascimento é: ${datadenasc}<br>'
document.body.innerHTML+= 'Sua data de nascimento é: ${datadenasc}<br>'

const nomecompleto = prompt('Insira o seu nome completo é:')
document.body.innerHTML= 'Seu nome completo é: ${nomecompleto}<br>'
document.body.innerHTML+='Seu nome tem${nomecompleto.length}'

const quntletrastem = prompt('Seu nome tem quantas letras:')
document.body.innerHTML= prompt('Quantas letras tem o seu nome:')


const primeiraletra = prompt('seu nome completo é:')
document.body.innerHTML= 'Seu nome completo é: ${nomecomplet}<br>'


const primeindecedaletraA = prompt('Primeiro indece de letra a no seu nome:')
document.body.innerHTML= 'Seu nome completo é: ${nomecomplet}<br>'


