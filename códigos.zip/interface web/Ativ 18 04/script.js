const cores=['Azul', 'Verde', 'Vermelho', 'Preto', 'Amarelo']
console.log(cores[0], cores[2]);

const animais=['Vaca', 'Elefante', 'Zebra', 'Lobo']
console.log(animais.slice (1,3));

const numerosInteiros=['1','2', '3', '4', '5', '6', '7', '8', '9', '0']
console.log(numerosInteiros.length);

const frutas=['Laranja', 'Uva', 'Tomate']
frutas.push('Melão')
console.log(frutas)



