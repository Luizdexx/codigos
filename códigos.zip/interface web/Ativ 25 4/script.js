function escopo(){
    const form = document.querySelector('.form')
    const resultado = document.querySelector('.resultado')
}
    const numeros = [];

     function recebeEventosForm(evento){
        evento.preventDefault();

        const numero = form.querySelector('.numero')
        numeros.push({
            
        })
     }
    
