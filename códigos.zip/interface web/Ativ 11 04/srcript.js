const numero= parseFloat(prompt('Informe um número:'));
const numUser= document.getElementById('numero-usuario');
const raiz=document.getElementById('raiz-user');
const inter=document.getElementById('inter-user');
const NaNuser=document.getElementById('NaN-user');
const arrebaixo=document.getElementById('arrebaixo-user');
const arrealto=document.getElementById('arrecima-user');
const duascasasdecimais=document.getElementById('duasCasasDecimais-user');

numUser.innerHTML = numero;
raiz.innerHTML = Math.sqrt(numero);
inter.innerHTML = Math.trunc(numero);
NaNuser.innerHTML = Number.isNaN(numero);
arrebaixo.innerHTML = Math.floor(numero);
arrealto.innerHTML = Math.ceil(numero);
duascasasdecimais.innerHTML = numero.toFixed(2);