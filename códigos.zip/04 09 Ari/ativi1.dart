// ignore_for_file: unused_local_variable, unused_import

import 'dart:math';

void executar (Function soma, Function subtracao, Function divide, Function multiplicacao){
 print("""Soma: ${soma()}, Subtracao: ${subtracao()}, Divisão: ${divide()}, Multiplica: ${multiplicacao()}""");
}

void main (){
  var n1 = 10;
  var n2 = 5;

  var somar = () => (n1 + n2);
  var subtracao = () => (n1 - n2);
  var divisao = () => (n1 / n2);
  var multiplicar = () => (n1 * n2);
}