//criando função que recebe duas variáveis
//do tipo função como parâmetro
import 'dart:math';

void executar(Function fnpar, Function fnImpar){
  //sorteando um número entre 0 e 9
  var sorteado = Random().nextInt(10);
  //mostrando valor sorteado
  print('O valor sorteado foi $sorteado');
  //if simplificado
  sorteado % 2 == 0 ? fnpar() : fnImpar();
}

void main() {
  //variável recebe função que retorna print
  var minhaFnPar = () => print('O valor é par');
  var minhaFnImpar = () => print("Valor Impar");

  //Chamando a função executar e passando
  //duas funções como parâmetro
  executar(minhaFnPar, minhaFnImpar);
}