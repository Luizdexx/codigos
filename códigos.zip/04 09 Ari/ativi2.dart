// ignore_for_file: unused_local_variable

import 'dart:math';

void executar (Function multiplica, Function divide){
  print("""Multiplica: ${multiplica()}, Divide: ${divide()}""");
  var sorteado = Random().nextInt(10);
  print("O valor sorteado é : $sorteado");
   
}

void main(){
  var multiplicacao = () => ('O valor da multiplicação é:');
  var divisao = () => ('O valor da divisão é:');
}