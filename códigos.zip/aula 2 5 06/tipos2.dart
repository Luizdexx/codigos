void man(){
  String s1 = "Bom ";
  String s2 = "dia";

  print(s1 + s2.toUpperCase() + "!!!");

  bool estaChovendo = false;
  bool estaFrio = true;

  print(estaChovendo || estaFrio);

  dynamic x = "Bom dia alunos";
  print(x);
  x = 16;
  print(x);
  x = false;
  print(x);
}