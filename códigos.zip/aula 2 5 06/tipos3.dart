void man(){
  //List
  //Conjunto de elementos indexados a partir de 0
  //Pode ter repetição e aceita dados de tipos diferentes
  List nomes= ['Ana', 'Andressa', 'Ariane', 'Angelica',];
  nomes.add('Alessandra');
  print(nomes);
  print(nomes[3]);
  print(nomes.length);
}