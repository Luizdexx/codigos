void man(){
  int n1 = 3;
  double n2 = (-5.67).abs();
  double n3 = double.parse("12.765");
  num n4 = 6;
  n4 = 25;

  print(n1 + n2 + n3 + n4);
}