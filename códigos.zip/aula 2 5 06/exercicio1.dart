void man(){
  List nomes = ['Maria', 'Marilha', 'Marina', 'Matilda', 'Marta', 'Matheus', 'Marte'];
  nomes.addAll(['Marilda', 'Maisa']);
}